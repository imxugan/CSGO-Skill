<?php

function isProfanity($input) {
    // TODO
}

?>
