<?php

define("DB_SERVER", "localhost");
define("USERNAME", "flareesp_flaredevo");
define("PASSWORD", "LOZ#^%TGoWRd,%ssxI");
define("UPDATEDB", "flareesp_update");
define("FLAREDB", "flareesp_db");

?>
