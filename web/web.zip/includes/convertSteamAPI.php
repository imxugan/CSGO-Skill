<?php

/**
 * This file can be  included when another script needs to convert a JSON object
 * of a user's $stats to our own naming convention.
 */

// TODO

?>
