<?php

define("DB_SERVER", "localhost");
define("USERNAME", "flaredevo");
define("PASSWORD", "LOZ#^%TGoWRd,%ssxI");
define("UPDATEDB", "flare-update");
define("FLAREDB", "flare-db");

?>
